Config.helpLinks.push({
    url: "http://support.networkoptix.com",
    title: "Support",
    description:"Have a question about specific features of your Nx MetaVMS system?",
    button:"get support",
    target: "new" // new|frame
});

Config.helpLinks.push({
    url: "http://networkoptix.com/calculator/#/",
    title: "System calculator",
    description:"Building a new Nx MetaVMS system or expanding your current system? Use the Nx System Calculator to calculate suggested storage and network requirements.",
    button: "Go to the calculator",
    target: "new" // new|frame
});


Config.helpLinks.push({
    urls: [
        {
            url: "https://itunes.apple.com/eg/app/hd-witness/id1050899754?mt=8",
            button: "iOS Client",
            class:'appstore'
        },
        {
            url: "https://play.google.com/store/apps/details?id=com.networkoptix.nxwitness",
            class:'googleplay',
            button: "Android Client"
        }
    ],
    title: "Mobile Apps",
    target: "new" // new|frame
});

Config.allowDebugMode = false;
Config.productName = 'Nx MetaVMS';
Config.cloud.productName = 'Cloud';
Config.defaultLanguage = 'en_US';
Config.supportedLanguages = ['en_US', 'ca_ES', 'cs_CZ', 'de_DE', 'en_GB', 'es_ES', 'fi_FI', 'fr_FR', 'he_IL', 'hu_HU', 'it_IT', 'ja_JP', 'ko_KR', 'nl_BE', 'nl_NL', 'no_NO', 'pl_PL', 'pt_BR', 'pt_PT', 'ru_RU', 'sv_SE', 'th_TH', 'tr_TR', 'uk_UA', 'vi_VN', 'zh_CN', 'zh_TW'];
Config.developersFeedbackForm = 'https://support.networkoptix.com/hc/en-us/community/topics/115000552988-Developer-Forum';
Config.developersKnowledgeBase = 'https://support.networkoptix.com/hc/en-us/categories/360000737654-Develop-with-Nx-Meta';